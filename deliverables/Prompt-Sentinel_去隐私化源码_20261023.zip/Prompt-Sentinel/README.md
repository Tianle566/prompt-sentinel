# Prompt Sentinel

提示词注入攻击检测与多层防护系统。后端使用 FastAPI，前端使用 Vue 3 / Vite；支持对话对照、攻击测试、TXT 文档摘要、日志统计、防护策略和评测。

本目录为去隐私化源码副本。包含业务源码、现有测试、依赖清单、启动与下载脚本、接口约定及 Mermaid 架构图。处理范围见 [去隐私化说明](PRIVACY.md)。原始账户、数据库、请求与回复、实验结果、截图、论文和答辩材料不在此包内。

## 安装与一键启动

需要 Python 3.11、Node.js 20.19+ 或 22.12+，以及可访问 PyPI、npm、Hugging Face 和 GitHub 的网络。首次安装需要下载依赖、模型及公共数据，请保留至少 12GB 磁盘空间。可使用 uv 管理 Python 环境。

macOS / Linux，在解压后的项目根目录运行：

```bash
chmod +x start.sh
./start.sh --setup
```

Windows 安装 Python 3.11 和 Node.js 后，双击 `start.bat`，或在命令行执行：

```bat
start.bat --setup
```

启动器会安装依赖与本地 Ollama、下载模型、构建公共评测数据，然后启动前后端。后续执行 `./start.sh` 或 `start.bat`。`./start.sh --check` 校验配置；首次执行时仍可能安装 Python 依赖。Ctrl+C 停止本次启动的服务。服务日志保存在 `.runtime/`。

部署必须使用单 worker：金丝雀会话、登录计数和任务队列保存在单个进程内；uvicorn 不要加 `--workers`。

- 前端：http://127.0.0.1:5173
- Swagger：http://127.0.0.1:8000/docs
- 健康检查：http://127.0.0.1:8000/api/health

首次后端启动会生成 `admin` 和 `user` 账户的随机密码，保存到 `.runtime/credentials.json`；JWT 密钥在未设置环境变量时随机生成并保存在 `.runtime/jwt-secret`。该源码包不含上述运行文件。也可在首次启动前设置 `SENTINEL_ADMIN_PASSWORD`、`SENTINEL_USER_PASSWORD`、`SENTINEL_JWT_SECRET`。数据库已有账户时不会自动覆盖其密码。

## 分步安装与验证

在项目根目录创建 Python 环境并安装依赖：

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r backend/requirements.txt
.venv/bin/python scripts/serve.py --check
.venv/bin/python -m pytest -q -m "not integration"
```

Windows 将 `.venv/bin/python` 替换为 `.venv\Scripts\python.exe`。`backend/requirements.lock.txt` 保留依赖版本记录，跨平台安装优先使用 `requirements.txt`。

前端构建：

```bash
cd frontend
npm ci
npm run build
```

非集成测试使用合成测试夹具；涉及密码、令牌、金丝雀与拒绝访问的字面值用于测试，不是实际运行账户。完整模型和公共语料准备好后，可运行完整测试和真实 smoke 检查：

```bash
.venv/bin/python scripts/smoke_test.py
.venv/bin/python -m pytest -q
```

此包不附模型权重、Ollama blobs、Python 环境、node_modules 和编译产物。默认通过 `--setup` 安装和下载；不能直接作为离线完整运行环境使用。

## 检测与防护

- L1：中英文规则。
- L2：DeBERTa 注入分类与滑动窗口。
- L3：Qwen3Guard 多语言审核。
- 融合：any、严格多数 vote、归一化 weighted；推理失败默认按 `fail_closed` 处理。
- L4：系统指令加固、随机边界、任务重申。
- L5：会话金丝雀、公共子串泄露检查和可选回复审核。

配置位于 `backend/config.yaml`，使用相对数据和模型路径、本机回环服务地址及通用用户名。检测模型来自 `protectai/deberta-v3-base-prompt-injection-v2` 与 `Qwen/Qwen3Guard-Gen-0.6B`；目标模型来自 `Qwen/Qwen3-1.7B-GGUF`，内存不足时选择配置中的 0.6B 版本。模型下载脚本会记录来源、revision 和哈希。

## 数据与四组实验

源码包不附原始或已处理语料。首次 `--setup` 从脚本指定的公共上游构建数据；也可运行：

```bash
.venv/bin/python scripts/build_dataset.py
.venv/bin/python scripts/run_eval.py --help
.venv/bin/python scripts/run_eval.py --experiment all --device cpu --limit 64 --asr-limit 10 --output-dir results/my-new-run
```

数据局限：`encoded` 与 `indirect` 模板样本由 `scripts/build_dataset.py` 本地构造，并非独立采集的真实攻击分布。模板数据的结果不能外推为真实攻击总体表现；上游安全风险标签也不等于严格的提示注入标签。

实验分别生成检测指标、防护 ASR、消融结果及延迟。原项目实验记录未随包提供，需自行运行生成结果。未知或失败请求保持未知，AI 复核不应表述为人工真值。`scripts/finalize_results.py`、`scripts/audit_results.py`、`scripts/import_results.py` 和 `scripts/record_ai_review.py` 提供整理、核对和导入工具。

## API、配置与数据

登录接口 `POST /api/auth/login` 接收 JSON 用户名和密码，后续接口使用 JWT Bearer。主要接口及数据结构见 [接口约定](docs/CONTRACT.md)，运行后以 Swagger 为准。普通用户查看自己的记录，管理员管理策略及评测。SQLite 数据库首次运行时在 `data/sentinel.db` 创建。

管理员将 `target.provider` 设为 `openai` 并修改 `target.base_url` 时，后端会将 `TARGET_API_KEY`（或 `target.api_key_env` 指定环境变量）的值作为 API 密钥发送到该地址；设置地址前应确认接收方受信任且有权接收该密钥。源码包仅保留环境变量名称，不含 API 密钥。

对照演示、攻击测试和 ASR 实验要求使用本机回环目标服务。数据库地址可通过 `SENTINEL_DATABASE_URL` 配置。运行数据、密钥和环境变量文件应保持在版本控制和分享包之外。

## 目录

```text
backend/     API、检测、防护、模型适配、数据库与测试
frontend/    Vue 页面、组件、样式及 npm 锁文件
scripts/     启动、模型下载、公共数据构建、评测及验证
docs/        接口约定、Mermaid 图和公开模型说明
PRIVACY.md   去隐私化范围和验证说明
```
